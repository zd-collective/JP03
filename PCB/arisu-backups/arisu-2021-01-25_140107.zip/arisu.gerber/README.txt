File descriptions:
- arisu-pcb-v1.1-mods-gerber.zip - An update to the Arisu v1.1 PCB, with USB-C, full backspace support, and stepped caps support.
- arisu-pcb-v1.1-mods-BOM.zip - The Bill of Materials and positioning files for ordering the PCB from JLCPCB.